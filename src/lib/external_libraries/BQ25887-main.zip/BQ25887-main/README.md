# BQ25887
Arduino library to control BQ25887 battery charge manager
